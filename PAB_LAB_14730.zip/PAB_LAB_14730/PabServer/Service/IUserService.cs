﻿using PabServer.Model;
using System.ServiceModel;


namespace PabServer.Service
{
    [ServiceContract]
    public interface IUserService
    {
        [OperationContract]
        string RegisterUser(User user);
    }
}
