﻿using System.Collections.Generic;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Moq;
using PabWebApi.Model;
using PabWebApi.Service;
using LMSApi.Controllers;
using Xunit;

public class EnrollmentControllerTests
{
    private readonly Mock<IEnrollmentService> _mockEnrollmentService;
    private readonly EnrollmentController _controller;

    public EnrollmentControllerTests()
    {
        _mockEnrollmentService = new Mock<IEnrollmentService>();
        _controller = new EnrollmentController(_mockEnrollmentService.Object);
    }

    [Fact]
    public async Task GetEnrollments_ReturnsOkResult_WithListOfEnrollments()
    {
        var enrollments = new List<Enrollment> { new Enrollment { Id = 1, CourseId = 1, StudentId = 1, EnrollmentDate = DateTime.Now } };
        _mockEnrollmentService.Setup(service => service.GetEnrollmentsAsync()).ReturnsAsync(enrollments);

        var result = await _controller.GetEnrollments();

        var okResult = Assert.IsType<OkObjectResult>(result.Result);
        var returnEnrollments = Assert.IsType<List<Enrollment>>(okResult.Value);
        Assert.Single(returnEnrollments);
    }

    [Fact]
    public async Task GetEnrollment_ReturnsOkResult_WithEnrollment()
    {
        var enrollment = new Enrollment { Id = 1, CourseId = 1, StudentId = 1, EnrollmentDate = DateTime.Now };
        _mockEnrollmentService.Setup(service => service.GetEnrollmentByIdAsync(1)).ReturnsAsync(enrollment);

        var result = await _controller.GetEnrollment(1);

        var okResult = Assert.IsType<OkObjectResult>(result.Result);
        var returnEnrollment = Assert.IsType<Enrollment>(okResult.Value);
        Assert.Equal(1, returnEnrollment.Id);
    }

    [Fact]
    public async Task GetEnrollment_ReturnsNotFound_WhenEnrollmentNotFound()
    {
        _mockEnrollmentService.Setup(service => service.GetEnrollmentByIdAsync(1)).ReturnsAsync((Enrollment)null);

        var result = await _controller.GetEnrollment(1);

        Assert.IsType<NotFoundResult>(result.Result);
    }

    [Fact]
    public async Task CreateEnrollment_ReturnsCreatedAtAction_WithEnrollment()
    {
        var enrollment = new Enrollment { Id = 1, CourseId = 1, StudentId = 1, EnrollmentDate = DateTime.Now };
        _mockEnrollmentService.Setup(service => service.CreateEnrollmentAsync(enrollment)).Returns(Task.CompletedTask);

        var result = await _controller.CreateEnrollment(enrollment);

        var createdAtActionResult = Assert.IsType<CreatedAtActionResult>(result.Result);
        var returnEnrollment = Assert.IsType<Enrollment>(createdAtActionResult.Value);
        Assert.Equal(1, returnEnrollment.Id);
    }

    [Fact]
    public async Task UpdateEnrollment_ReturnsNoContent()
    {
        var enrollment = new Enrollment { Id = 1, CourseId = 1, StudentId = 1, EnrollmentDate = DateTime.Now };
        _mockEnrollmentService.Setup(service => service.UpdateEnrollmentAsync(enrollment)).Returns(Task.CompletedTask);

        var result = await _controller.UpdateEnrollment(1, enrollment);

        Assert.IsType<NoContentResult>(result);
    }

    [Fact]
    public async Task UpdateEnrollment_ReturnsBadRequest_WhenIdMismatch()
    {
        var enrollment = new Enrollment { Id = 1, CourseId = 1, StudentId = 1, EnrollmentDate = DateTime.Now };

        var result = await _controller.UpdateEnrollment(2, enrollment);

        Assert.IsType<BadRequestResult>(result);
    }

    [Fact]
    public async Task DeleteEnrollment_ReturnsNoContent()
    {
        _mockEnrollmentService.Setup(service => service.DeleteEnrollmentAsync(1)).Returns(Task.CompletedTask);

        var result = await _controller.DeleteEnrollment(1);

        Assert.IsType<NoContentResult>(result);
    }
}
