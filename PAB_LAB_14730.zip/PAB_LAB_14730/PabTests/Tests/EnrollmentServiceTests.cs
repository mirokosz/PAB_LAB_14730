﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using PabWebApi;
using PabWebApi.Model;
using PabWebApi.Service;
using Xunit;

public class EnrollmentServiceTests : IDisposable
{
    private readonly EnrollmentService _service;
    private readonly ApplicationDbContext _context;

    public EnrollmentServiceTests()
    {
        var options = new DbContextOptionsBuilder<ApplicationDbContext>()
            .UseInMemoryDatabase(databaseName: "EnrollmentServiceTestDatabase")
            .EnableSensitiveDataLogging()
            .Options;

        _context = new ApplicationDbContext(options);
        _service = new EnrollmentService(_context);
    }

    [Fact]
    public async Task GetEnrollmentsAsync_ReturnsListOfEnrollments()
    {
        var enrollments = new List<Enrollment>
        {
            new Enrollment { Id = 1, CourseId = 1, StudentId = 1, EnrollmentDate = DateTime.Now }
        };
        _context.Enrollments.AddRange(enrollments);
        await _context.SaveChangesAsync();

        var result = await _service.GetEnrollmentsAsync();

        Assert.Single(result);
        Assert.Equal(1, result[0].Id);
    }

    [Fact]
    public async Task GetEnrollmentByIdAsync_ReturnsEnrollment()
    {
        var enrollment = new Enrollment { Id = 1, CourseId = 1, StudentId = 1, EnrollmentDate = DateTime.Now };
        _context.Enrollments.Add(enrollment);
        await _context.SaveChangesAsync();

        var result = await _service.GetEnrollmentByIdAsync(1);

        Assert.Equal(1, result.Id);
        Assert.Equal(1, result.CourseId);
        Assert.Equal(1, result.StudentId);
        Assert.Equal(enrollment.EnrollmentDate, result.EnrollmentDate);
    }

    [Fact]
    public async Task CreateEnrollmentAsync_AddsEnrollment()
    {
        var enrollment = new Enrollment { Id = 1, CourseId = 1, StudentId = 1, EnrollmentDate = DateTime.Now };

        await _service.CreateEnrollmentAsync(enrollment);
        var result = await _context.Enrollments.FindAsync(1);

        Assert.NotNull(result);
        Assert.Equal(1, result.Id);
        Assert.Equal(1, result.CourseId);
        Assert.Equal(1, result.StudentId);
        Assert.Equal(enrollment.EnrollmentDate, result.EnrollmentDate);
    }

    [Fact]
    public async Task UpdateEnrollmentAsync_UpdatesEnrollment()
    {
        var enrollment = new Enrollment { Id = 1, CourseId = 1, StudentId = 1, EnrollmentDate = DateTime.Now };
        _context.Enrollments.Add(enrollment);
        await _context.SaveChangesAsync();

        enrollment.CourseId = 2;
        enrollment.StudentId = 2;
        enrollment.EnrollmentDate = DateTime.Now.AddDays(1);

        await _service.UpdateEnrollmentAsync(enrollment);
        var result = await _context.Enrollments.FindAsync(1);

        Assert.Equal(2, result.CourseId);
        Assert.Equal(2, result.StudentId);
        Assert.Equal(enrollment.EnrollmentDate, result.EnrollmentDate);
    }

    [Fact]
    public async Task DeleteEnrollmentAsync_DeletesEnrollment()
    {
        var enrollment = new Enrollment { Id = 1, CourseId = 1, StudentId = 1, EnrollmentDate = DateTime.Now };
        _context.Enrollments.Add(enrollment);
        await _context.SaveChangesAsync();

        await _service.DeleteEnrollmentAsync(1);
        var result = await _context.Enrollments.FindAsync(1);

        Assert.Null(result);
    }

    public void Dispose()
    {
        _context.Database.EnsureDeleted();
        _context.Dispose();
    }
}
