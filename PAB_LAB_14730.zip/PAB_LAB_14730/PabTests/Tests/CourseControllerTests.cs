﻿using System.Collections.Generic;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Moq;
using PabWebApi.Model;
using PabWebApi.Service;
using LMSApi.Controllers;
using Xunit;

public class CourseControllerTests
{
    private readonly Mock<ICourseService> _mockCourseService;
    private readonly CourseController _controller;

    public CourseControllerTests()
    {
        _mockCourseService = new Mock<ICourseService>();
        _controller = new CourseController(_mockCourseService.Object);
    }

    [Fact]
    public async Task GetCourses_ReturnsOkResult_WithListOfCourses()
    {
        var courses = new List<Course> { new Course { Id = 1, Title = "Test Course" } };
        _mockCourseService.Setup(service => service.GetCoursesAsync()).ReturnsAsync(courses);

        var result = await _controller.GetCourses();

        var okResult = Assert.IsType<OkObjectResult>(result.Result);
        var returnCourses = Assert.IsType<List<Course>>(okResult.Value);
        Assert.Single(returnCourses);
    }

    [Fact]
    public async Task GetCourse_ReturnsOkResult_WithCourse()
    {
        var course = new Course { Id = 1, Title = "Test Course" };
        _mockCourseService.Setup(service => service.GetCourseByIdAsync(1)).ReturnsAsync(course);

        var result = await _controller.GetCourse(1);

        var okResult = Assert.IsType<OkObjectResult>(result.Result);
        var returnCourse = Assert.IsType<Course>(okResult.Value);
        Assert.Equal(1, returnCourse.Id);
    }

    [Fact]
    public async Task GetCourse_ReturnsNotFound_WhenCourseNotFound()
    {
        _mockCourseService.Setup(service => service.GetCourseByIdAsync(1)).ReturnsAsync((Course)null);

        var result = await _controller.GetCourse(1);

        Assert.IsType<NotFoundResult>(result.Result);
    }

    [Fact]
    public async Task CreateCourse_ReturnsCreatedAtAction_WithCourse()
    {
        var course = new Course { Id = 1, Title = "Test Course" };
        _mockCourseService.Setup(service => service.CreateCourseAsync(course)).Returns(Task.CompletedTask);

        var result = await _controller.CreateCourse(course);

        var createdAtActionResult = Assert.IsType<CreatedAtActionResult>(result.Result);
        var returnCourse = Assert.IsType<Course>(createdAtActionResult.Value);
        Assert.Equal(1, returnCourse.Id);
    }

    [Fact]
    public async Task UpdateCourse_ReturnsNoContent()
    {
        var course = new Course { Id = 1, Title = "Test Course" };
        _mockCourseService.Setup(service => service.UpdateCourseAsync(course)).Returns(Task.CompletedTask);

        var result = await _controller.UpdateCourse(1, course);

        Assert.IsType<NoContentResult>(result);
    }

    [Fact]
    public async Task UpdateCourse_ReturnsBadRequest_WhenIdMismatch()
    {
        var course = new Course { Id = 1, Title = "Test Course" };

        var result = await _controller.UpdateCourse(2, course);

        Assert.IsType<BadRequestResult>(result);
    }

    [Fact]
    public async Task DeleteCourse_ReturnsNoContent()
    {
        _mockCourseService.Setup(service => service.DeleteCourseAsync(1)).Returns(Task.CompletedTask);

        var result = await _controller.DeleteCourse(1);

        Assert.IsType<NoContentResult>(result);
    }
}
