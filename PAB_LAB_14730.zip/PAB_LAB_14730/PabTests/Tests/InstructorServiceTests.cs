﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using PabWebApi;
using PabWebApi.Model;
using PabWebApi.Service;
using Xunit;

public class InstructorServiceTests : IDisposable
{
    private readonly InstructorService _service;
    private readonly ApplicationDbContext _context;

    public InstructorServiceTests()
    {
        var options = new DbContextOptionsBuilder<ApplicationDbContext>()
            .UseInMemoryDatabase(databaseName: "InstructorServiceTestDatabase")
            .EnableSensitiveDataLogging()
            .Options;

        _context = new ApplicationDbContext(options);
        _service = new InstructorService(_context);
    }

    [Fact]
    public async Task GetInstructorsAsync_ReturnsListOfInstructors()
    {
        var instructors = new List<Instructor>
        {
            new Instructor { Id = 1, FirstName = "John", LastName = "Doe", Email = "john.doe@example.com", PhoneNumber = "1234567890" }
        };
        _context.Instructors.AddRange(instructors);
        await _context.SaveChangesAsync();

        var result = await _service.GetInstructorsAsync();

        Assert.Single(result);
        Assert.Equal(1, result[0].Id);
    }

    [Fact]
    public async Task GetInstructorByIdAsync_ReturnsInstructor()
    {
        var instructor = new Instructor { Id = 1, FirstName = "John", LastName = "Doe", Email = "john.doe@example.com", PhoneNumber = "1234567890" };
        _context.Instructors.Add(instructor);
        await _context.SaveChangesAsync();

        var result = await _service.GetInstructorByIdAsync(1);

        Assert.Equal(1, result.Id);
        Assert.Equal("John", result.FirstName);
        Assert.Equal("Doe", result.LastName);
        Assert.Equal("john.doe@example.com", result.Email);
        Assert.Equal("1234567890", result.PhoneNumber);
    }

    [Fact]
    public async Task CreateInstructorAsync_AddsInstructor()
    {
        var instructor = new Instructor { Id = 1, FirstName = "John", LastName = "Doe", Email = "john.doe@example.com", PhoneNumber = "1234567890" };

        await _service.CreateInstructorAsync(instructor);
        var result = await _context.Instructors.FindAsync(1);

        Assert.NotNull(result);
        Assert.Equal(1, result.Id);
        Assert.Equal("John", result.FirstName);
        Assert.Equal("Doe", result.LastName);
        Assert.Equal("john.doe@example.com", result.Email);
        Assert.Equal("1234567890", result.PhoneNumber);
    }

    [Fact]
    public async Task UpdateInstructorAsync_UpdatesInstructor()
    {
        var instructor = new Instructor { Id = 1, FirstName = "John", LastName = "Doe", Email = "john.doe@example.com", PhoneNumber = "1234567890" };
        _context.Instructors.Add(instructor);
        await _context.SaveChangesAsync();

        instructor.FirstName = "Jane";
        instructor.LastName = "Smith";
        instructor.Email = "jane.smith@example.com";
        instructor.PhoneNumber = "0987654321";

        await _service.UpdateInstructorAsync(instructor);
        var result = await _context.Instructors.FindAsync(1);

        Assert.Equal("Jane", result.FirstName);
        Assert.Equal("Smith", result.LastName);
        Assert.Equal("jane.smith@example.com", result.Email);
        Assert.Equal("0987654321", result.PhoneNumber);
    }

    [Fact]
    public async Task DeleteInstructorAsync_DeletesInstructor()
    {
        var instructor = new Instructor { Id = 1, FirstName = "John", LastName = "Doe", Email = "john.doe@example.com", PhoneNumber = "1234567890" };
        _context.Instructors.Add(instructor);
        await _context.SaveChangesAsync();

        await _service.DeleteInstructorAsync(1);
        var result = await _context.Instructors.FindAsync(1);

        Assert.Null(result);
    }

    public void Dispose()
    {
        _context.Database.EnsureDeleted();
        _context.Dispose();
    }
}
