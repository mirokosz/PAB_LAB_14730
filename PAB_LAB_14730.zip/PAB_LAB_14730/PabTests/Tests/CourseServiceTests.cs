﻿using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using PabWebApi;
using PabWebApi.Model;
using PabWebApi.Service;
using Xunit;

public class CourseServiceTests : IDisposable
{
    private readonly CourseService _service;
    private readonly ApplicationDbContext _context;

    public CourseServiceTests()
    {
        var options = new DbContextOptionsBuilder<ApplicationDbContext>()
            .UseInMemoryDatabase(databaseName: "CourseServiceTestDatabase")
            .EnableSensitiveDataLogging() // Dodaj tę linię
            .Options;

        _context = new ApplicationDbContext(options);
        _service = new CourseService(_context);
    }

    [Fact]
    public async Task GetCoursesAsync_ReturnsListOfCourses()
    {
        var courses = new List<Course>
        {
            new Course { Id = 1, Title = "Test Course", Category = "Test Category", Description = "Test Description", Instructor = "Test Instructor" }
        };
        _context.Courses.AddRange(courses);
        await _context.SaveChangesAsync();

        var result = await _service.GetCoursesAsync();

        Assert.Single(result);
        Assert.Equal(1, result[0].Id);
    }

    [Fact]
    public async Task GetCourseByIdAsync_ReturnsCourse()
    {
        var course = new Course { Id = 1, Title = "Test Course", Category = "Test Category", Description = "Test Description", Instructor = "Test Instructor" };
        _context.Courses.Add(course);
        await _context.SaveChangesAsync();

        var result = await _service.GetCourseByIdAsync(1);

        Assert.Equal(1, result.Id);
        Assert.Equal("Test Course", result.Title);
        Assert.Equal("Test Category", result.Category);
        Assert.Equal("Test Description", result.Description);
        Assert.Equal("Test Instructor", result.Instructor);
    }

    [Fact]
    public async Task CreateCourseAsync_AddsCourse()
    {
        var course = new Course { Id = 1, Title = "Test Course", Category = "Test Category", Description = "Test Description", Instructor = "Test Instructor" };

        await _service.CreateCourseAsync(course);
        var result = await _context.Courses.FindAsync(1);

        Assert.NotNull(result);
        Assert.Equal(1, result.Id);
        Assert.Equal("Test Course", result.Title);
        Assert.Equal("Test Category", result.Category);
        Assert.Equal("Test Description", result.Description);
        Assert.Equal("Test Instructor", result.Instructor);
    }

    [Fact]
    public async Task UpdateCourseAsync_UpdatesCourse()
    {
        var course = new Course { Id = 1, Title = "Test Course", Category = "Test Category", Description = "Test Description", Instructor = "Test Instructor" };
        _context.Courses.Add(course);
        await _context.SaveChangesAsync();

        course.Title = "Updated Course";
        course.Category = "Updated Category";
        course.Description = "Updated Description";
        course.Instructor = "Updated Instructor";

        await _service.UpdateCourseAsync(course);
        var result = await _context.Courses.FindAsync(1);

        Assert.Equal("Updated Course", result.Title);
        Assert.Equal("Updated Category", result.Category);
        Assert.Equal("Updated Description", result.Description);
        Assert.Equal("Updated Instructor", result.Instructor);
    }

    [Fact]
    public async Task DeleteCourseAsync_DeletesCourse()
    {
        var course = new Course { Id = 1, Title = "Test Course", Category = "Test Category", Description = "Test Description", Instructor = "Test Instructor" };
        _context.Courses.Add(course);
        await _context.SaveChangesAsync();

        await _service.DeleteCourseAsync(1);
        var result = await _context.Courses.FindAsync(1);

        Assert.Null(result);
    }

    public void Dispose()
    {
        _context.Database.EnsureDeleted();
        _context.Dispose();
    }
}
