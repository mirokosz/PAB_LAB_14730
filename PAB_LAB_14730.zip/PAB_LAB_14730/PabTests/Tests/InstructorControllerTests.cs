﻿using System.Collections.Generic;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Moq;
using PabWebApi.Model;
using PabWebApi.Service;
using LMSApi.Controllers;
using Xunit;

public class InstructorControllerTests
{
    private readonly Mock<IInstructorService> _mockInstructorService;
    private readonly InstructorController _controller;

    public InstructorControllerTests()
    {
        _mockInstructorService = new Mock<IInstructorService>();
        _controller = new InstructorController(_mockInstructorService.Object);
    }

    [Fact]
    public async Task GetInstructors_ReturnsOkResult_WithListOfInstructors()
    {
        var instructors = new List<Instructor> { new Instructor { Id = 1, FirstName = "John", LastName = "Doe", Email = "john.doe@example.com", PhoneNumber = "1234567890" } };
        _mockInstructorService.Setup(service => service.GetInstructorsAsync()).ReturnsAsync(instructors);

        var result = await _controller.GetInstructors();

        var okResult = Assert.IsType<OkObjectResult>(result.Result);
        var returnInstructors = Assert.IsType<List<Instructor>>(okResult.Value);
        Assert.Single(returnInstructors);
    }

    [Fact]
    public async Task GetInstructor_ReturnsOkResult_WithInstructor()
    {
        var instructor = new Instructor { Id = 1, FirstName = "John", LastName = "Doe", Email = "john.doe@example.com", PhoneNumber = "1234567890" };
        _mockInstructorService.Setup(service => service.GetInstructorByIdAsync(1)).ReturnsAsync(instructor);

        var result = await _controller.GetInstructor(1);

        var okResult = Assert.IsType<OkObjectResult>(result.Result);
        var returnInstructor = Assert.IsType<Instructor>(okResult.Value);
        Assert.Equal(1, returnInstructor.Id);
    }

    [Fact]
    public async Task GetInstructor_ReturnsNotFound_WhenInstructorNotFound()
    {
        _mockInstructorService.Setup(service => service.GetInstructorByIdAsync(1)).ReturnsAsync((Instructor)null);

        var result = await _controller.GetInstructor(1);

        Assert.IsType<NotFoundResult>(result.Result);
    }

    [Fact]
    public async Task CreateInstructor_ReturnsCreatedAtAction_WithInstructor()
    {
        var instructor = new Instructor { Id = 1, FirstName = "John", LastName = "Doe", Email = "john.doe@example.com", PhoneNumber = "1234567890" };
        _mockInstructorService.Setup(service => service.CreateInstructorAsync(instructor)).Returns(Task.CompletedTask);

        var result = await _controller.CreateInstructor(instructor);

        var createdAtActionResult = Assert.IsType<CreatedAtActionResult>(result.Result);
        var returnInstructor = Assert.IsType<Instructor>(createdAtActionResult.Value);
        Assert.Equal(1, returnInstructor.Id);
    }

    [Fact]
    public async Task UpdateInstructor_ReturnsNoContent()
    {
        var instructor = new Instructor { Id = 1, FirstName = "John", LastName = "Doe", Email = "john.doe@example.com", PhoneNumber = "1234567890" };
        _mockInstructorService.Setup(service => service.UpdateInstructorAsync(instructor)).Returns(Task.CompletedTask);

        var result = await _controller.UpdateInstructor(1, instructor);

        Assert.IsType<NoContentResult>(result);
    }

    [Fact]
    public async Task UpdateInstructor_ReturnsBadRequest_WhenIdMismatch()
    {
        var instructor = new Instructor { Id = 1, FirstName = "John", LastName = "Doe", Email = "john.doe@example.com", PhoneNumber = "1234567890" };

        var result = await _controller.UpdateInstructor(2, instructor);

        Assert.IsType<BadRequestResult>(result);
    }

    [Fact]
    public async Task DeleteInstructor_ReturnsNoContent()
    {
        _mockInstructorService.Setup(service => service.DeleteInstructorAsync(1)).Returns(Task.CompletedTask);

        var result = await _controller.DeleteInstructor(1);

        Assert.IsType<NoContentResult>(result);
    }
}
