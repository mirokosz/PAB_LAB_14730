﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using PabRazor.Models;

namespace PabRazor.Data
{
    public class PabRazorContext : DbContext
    {
        public PabRazorContext (DbContextOptions<PabRazorContext> options)
            : base(options)
        {
        }

        public DbSet<PabRazor.Models.Course> Course { get; set; } = default!;
        public DbSet<PabRazor.Models.Enrollment> Enrollment { get; set; } = default!;
        public DbSet<PabRazor.Models.Instructor> Instructor { get; set; } = default!;
    }
}
