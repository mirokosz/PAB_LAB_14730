﻿using System.ComponentModel.DataAnnotations;

namespace PabWebApi.Model
{
    public class Enrollment
    {
        [Key]
        public int Id { get; set; }

        [Required]
        public int CourseId { get; set; }

        [Required]
        public int StudentId { get; set; }

        [Required]
        public DateTime EnrollmentDate { get; set; }
    }
}
