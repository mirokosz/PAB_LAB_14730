﻿using Microsoft.EntityFrameworkCore;
using PabWebApi;
using PabWebApi.Model;
using PabWebApi.Service;

namespace PabWebApi.Service
{
    public interface IInstructorService
    {
        Task<List<Instructor>> GetInstructorsAsync();
        Task<Instructor> GetInstructorByIdAsync(int id);
        Task CreateInstructorAsync(Instructor instructor);
        Task UpdateInstructorAsync(Instructor instructor);
        Task DeleteInstructorAsync(int id);
    }
}

public class InstructorService : IInstructorService
{
    private readonly ApplicationDbContext _context;

    public InstructorService(ApplicationDbContext context)
    {
        _context = context;
    }

    public async Task<List<Instructor>> GetInstructorsAsync()
    {
        return await _context.Instructors.ToListAsync();
    }

    public async Task<Instructor> GetInstructorByIdAsync(int id)
    {
        return await _context.Instructors.FindAsync(id);
    }

    public async Task CreateInstructorAsync(Instructor instructor)
    {
        _context.Instructors.Add(instructor);
        await _context.SaveChangesAsync();
    }

    public async Task UpdateInstructorAsync(Instructor instructor)
    {
        _context.Entry(instructor).State = EntityState.Modified;
        await _context.SaveChangesAsync();
    }

    public async Task DeleteInstructorAsync(int id)
    {
        var instructor = await _context.Instructors.FindAsync(id);
        if (instructor != null)
        {
            _context.Instructors.Remove(instructor);
            await _context.SaveChangesAsync();
        }
    }
}