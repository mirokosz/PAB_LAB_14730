﻿using Microsoft.EntityFrameworkCore;
using PabWebApi;
using PabWebApi.Model;
using PabWebApi.Service;

namespace PabWebApi.Service
{
    public interface IEnrollmentService
    {
        Task<List<Enrollment>> GetEnrollmentsAsync();
        Task<Enrollment> GetEnrollmentByIdAsync(int id);
        Task CreateEnrollmentAsync(Enrollment enrollment);
        Task UpdateEnrollmentAsync(Enrollment enrollment);
        Task DeleteEnrollmentAsync(int id);
    }
}

public class EnrollmentService : IEnrollmentService
{
    private readonly ApplicationDbContext _context;

    public EnrollmentService(ApplicationDbContext context)
    {
        _context = context;
    }

    public async Task<List<Enrollment>> GetEnrollmentsAsync()
    {
        return await _context.Enrollments.ToListAsync();
    }

    public async Task<Enrollment> GetEnrollmentByIdAsync(int id)
    {
        return await _context.Enrollments.FindAsync(id);
    }

    public async Task CreateEnrollmentAsync(Enrollment enrollment)
    {
        _context.Enrollments.Add(enrollment);
        await _context.SaveChangesAsync();
    }

    public async Task UpdateEnrollmentAsync(Enrollment enrollment)
    {
        _context.Entry(enrollment).State = EntityState.Modified;
        await _context.SaveChangesAsync();
    }

    public async Task DeleteEnrollmentAsync(int id)
    {
        var enrollment = await _context.Enrollments.FindAsync(id);
        if (enrollment != null)
        {
            _context.Enrollments.Remove(enrollment);
            await _context.SaveChangesAsync();
        }
    }
}